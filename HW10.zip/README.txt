Type "make" to build the program. 
In "comparison.gif", the ga search was executed with pop_size = 1000, mut_rate = 0.1. 

A zipfile is also uploaded in case the github does not work. 

test_chromosome only tests for some parts of the program to assist the debugging process. 
